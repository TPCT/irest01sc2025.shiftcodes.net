<?php return array (
  'root' => 
  array (
    'pretty_version' => '1.0.0+no-version-set',
    'version' => '1.0.0.0',
    'aliases' => 
    array (
    ),
    'reference' => NULL,
    'name' => '__root__',
  ),
  'versions' => 
  array (
    '__root__' => 
    array (
      'pretty_version' => '1.0.0+no-version-set',
      'version' => '1.0.0.0',
      'aliases' => 
      array (
      ),
      'reference' => NULL,
    ),
    'mike42/escpos-php' => 
    array (
      'pretty_version' => 'v3.0',
      'version' => '3.0.0.0',
      'aliases' => 
      array (
      ),
      'reference' => 'dcb569a123d75f9f6a4a927aae7625ca6b7fdcf3',
    ),
    'mike42/gfx-php' => 
    array (
      'pretty_version' => 'v0.6',
      'version' => '0.6.0.0',
      'aliases' => 
      array (
      ),
      'reference' => 'ed9ded2a9298e4084a9c557ab74a89b71e43dbdb',
    ),
  ),
);
